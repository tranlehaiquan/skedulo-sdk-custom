import * as React from 'react'
import * as ReactDOM from 'react-dom'

import './view/stylesheets/sass/skedulo-mobile.scss'

import { ConnectedPageNativeAttachments, ConnectedPageViewWidgets, ConnectedPageViewCallbacks, ViewDataState } from '@skedulo/sdk-utilities'

import App from './view/App'

export function bootstrap(
  refId: string,
  _data: ViewDataState<{}, {}>,
  nativeAttachments: ConnectedPageNativeAttachments,
  widgets: ConnectedPageViewWidgets,
  callbacks: ConnectedPageViewCallbacks<{}, {}>,
  callbackBootstrapComplete: () => void
) {
  ReactDOM.render(
    <App
      refId={ refId }
      attachmentServices={ nativeAttachments }
      callbacks={ callbacks }
    />,
    document.getElementById('root'),
    callbackBootstrapComplete
  )
}
