import { bootstrap } from './main'

import { createMCPView } from '@skedulo/sdk-utilities'

// Create new MCP view with bootstrap function
createMCPView(bootstrap, window)
