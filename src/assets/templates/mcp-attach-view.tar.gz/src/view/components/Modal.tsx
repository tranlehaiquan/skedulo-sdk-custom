import * as React from 'react'

interface Props {
}

export default class Modal extends React.Component<Props, {}> {
  constructor(props: Props) {
    super(props)
  }

  render() {
    return (
      <div className="notification">
        <div className="notification-wrapper">
          { this.props.children }
        </div>
      </div>
    )
  }
}
