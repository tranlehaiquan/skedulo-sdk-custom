import { flatMap, groupBy, mapValues } from 'lodash'
import { MCPFetchHandler, flattenGraphQlEdges, sanitizeGraphQLRawQueryData } from '@skedulo/sdk-utilities'

import { JobProductsManagedData, JobProductsCommonData, FetchProducts, FetchJobsWithJobProducts, fetchProducts, fetchJobsWithJobProducts } from 'mcp-jp-types'

export const fetchHandler: MCPFetchHandler<JobProductsManagedData, JobProductsCommonData> = async handlerInput => {
  const { services, referenceIds } = handlerInput

  const productResults = await services.GraphQLService.executeQueryForDocument<FetchProducts.Query, FetchProducts.Variables>(fetchProducts, {})
  const jobProductResults = await services.GraphQLService.executeQueryForDocument<FetchJobsWithJobProducts.Query, FetchJobsWithJobProducts.Variables>(fetchJobsWithJobProducts, {
    filter: `UID IN [${referenceIds.map(id => `"${id}"`).join(',')}]`
  })

  // Prepare data for storage
  const rawJobs = flattenGraphQlEdges(jobProductResults.jobs)
  const rawProducts = flattenGraphQlEdges(productResults.products)
  const rawJobProducts = flatMap(rawJobs, job => job.JobProducts)

  const flatJobProducts = sanitizeGraphQLRawQueryData(rawJobProducts)
  const jobProductsByJobId = groupBy(flatJobProducts, jp => jp.JobId)

  // Form managed source (data that can be changed)
  const managedSources = referenceIds.reduce<{ [jobId: string]: JobProductsManagedData }>((allJobs, jobId) => ({
    ...allJobs,
    [jobId]: {
      JobProducts: jobProductsByJobId[jobId] || []
    }
  }), {} as { [jobId: string]: JobProductsManagedData })

  const commonSources = {
    Products: sanitizeGraphQLRawQueryData(rawProducts)
  }

  return {
    managedSources,
    commonSources
  }
}
