import { flatMap, groupBy } from 'lodash'
import { MobileFetchHandler, flattenGraphQlEdges, sanitizeGraphQLRawQueryData, MobileFetchSources, MobileFetchCacheHandler } from '@skedulo/sdk-utilities'

import { JobProductsManagedData, JobProductsUnmanagedData, JobProductCacheData, FetchProducts, FetchJobsWithJobProducts, fetchProducts, fetchJobsWithJobProducts } from 'jp-typegen-library'

export const fetchHandler: MobileFetchHandler<JobProductsManagedData, JobProductsUnmanagedData> = async handlerInput => {
  const { services, referenceIds } = handlerInput

  
  const jobProductResults = await services.GraphQLService.executeQueryForDocument<FetchJobsWithJobProducts.Query, FetchJobsWithJobProducts.Variables>(fetchJobsWithJobProducts, {
    filter: `UID IN [${referenceIds.map(id => `"${id}"`).join(',')}]`
  })

  // Prepare data for storage
  const rawJobs = flattenGraphQlEdges(jobProductResults.jobs)
  const rawJobProducts = flatMap(rawJobs, job => job.JobProducts)

  const flatJobProducts = sanitizeGraphQLRawQueryData(rawJobProducts)
  const jobProductsByJobId = groupBy(flatJobProducts, jp => jp.JobId)

  const sources = referenceIds.reduce((allJobs, jobId) => ({
    ...allJobs,
    [jobId]: {
      managedSources: { JobProducts: jobProductsByJobId[jobId] || [] },
      unmanagedSources: {  }
    }
  }), {} as MobileFetchSources<JobProductsManagedData, JobProductsUnmanagedData>)

  return {
    sources
  }
}

export const fetchCacheHandler: MobileFetchCacheHandler<JobProductCacheData> = async ({services}) => {
  const result = await services.GraphQLService.executeFetchAutoPaginationForDocument<FetchProducts.Query, FetchProducts.Variables>(fetchProducts, {})
  return {
    Products: sanitizeGraphQLRawQueryData(result)
  }
}
