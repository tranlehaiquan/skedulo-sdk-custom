import { flatMap, groupBy } from 'lodash'
import { MobileFetchHandler, flattenGraphQlEdges, sanitizeGraphQLRawQueryData, MobileFetchSources } from '@skedulo/sdk-utilities'

import { JobProductsManagedData, JobProductsCommonData, FetchProducts, FetchJobsWithJobProducts, fetchProducts, fetchJobsWithJobProducts } from 'jp-typegen-library'

export const fetchHandler: MobileFetchHandler<JobProductsManagedData, JobProductsCommonData> = async handlerInput => {
  const { services, referenceIds } = handlerInput

  const productResults = await services.GraphQLService.executeQueryForDocument<FetchProducts.Query, FetchProducts.Variables>(fetchProducts, {})
  const jobProductResults = await services.GraphQLService.executeQueryForDocument<FetchJobsWithJobProducts.Query, FetchJobsWithJobProducts.Variables>(fetchJobsWithJobProducts, {
    filter: `UID IN [${referenceIds.map(id => `"${id}"`).join(',')}]`
  })

  // Prepare data for storage
  const rawJobs = flattenGraphQlEdges(jobProductResults.jobs)
  const rawProducts = flattenGraphQlEdges(productResults.products)
  const rawJobProducts = flatMap(rawJobs, job => job.JobProducts)

  const flatJobProducts = sanitizeGraphQLRawQueryData(rawJobProducts)
  const jobProductsByJobId = groupBy(flatJobProducts, jp => jp.JobId)

  const sources = referenceIds.reduce((allJobs, jobId) => ({
    ...allJobs,
    [jobId]: {
      managed: { JobProducts: jobProductsByJobId[jobId] || [] },
      unmanaged: { Products: sanitizeGraphQLRawQueryData(rawProducts) }
    }
  }), {} as MobileFetchSources<JobProductsManagedData, JobProductsCommonData>)

  return {
    sources
  }
}
