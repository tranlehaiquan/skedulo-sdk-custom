import { MobileFunction } from '@skedulo/sdk-utilities'
import { fetchCacheHandler, fetchHandler } from './data'

// Create a function instance with the given routes
const skeduloFunction = new MobileFunction({
  fetch: {
    handler: fetchHandler
  },
  save: {
    graphQLConfiguration: {
      optimize: {
        enabled: true,
        safeKeyMerging: true
      }
    }
  }, 
  fetchCache: {
    handler: fetchCacheHandler
  }
})

// Export the handler, this step is required!
skeduloFunction.attachHandler(module.exports)
