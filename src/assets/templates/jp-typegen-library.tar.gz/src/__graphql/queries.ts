declare module "*/queries.graphql" {
  import { DocumentNode } from "graphql";
  const defaultDocument: DocumentNode;
  const fetchJobsWithJobProducts: DocumentNode;
  const fetchProducts: DocumentNode;

  export { fetchJobsWithJobProducts, fetchProducts };

  export default defaultDocument;
}
