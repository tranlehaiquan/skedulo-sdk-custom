import * as React from 'react'
import * as ReactDOM from 'react-dom'

import './view/stylesheets/sass/skedulo-mobile.scss'

import { JobProductsManagedData, JobProductsUnmanagedData, JobProductCacheData } from 'jp-typegen-library'
import { MobileViewInitFn } from '@skedulo/sdk-utilities'

import App from './view/App'
import { generateStorageContainer, generateJobProductManager} from './data'

export const bootstrap: MobileViewInitFn<JobProductsManagedData, JobProductsUnmanagedData, JobProductCacheData> = ({data, refId, callbacks, cacheData, widgets, rootElement, bootstrapComplete}) => {
  // Generate storage container and managers for managed schemas
  const storageContainer = generateStorageContainer(data.managedSources)
  const jobProductManager = generateJobProductManager(storageContainer, refId)

  ReactDOM.render(
    <App
      refId={ refId }
      jobProductManager={ jobProductManager }
      storage={ storageContainer }
      common={ data.unmanagedSources }
      cacheData={cacheData || {Products: []}}
      widgets={ widgets }
      callbacks={ callbacks }
    />,
    rootElement,
    bootstrapComplete
  )
}
