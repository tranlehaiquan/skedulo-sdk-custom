import * as React from 'react'
import * as ReactDOM from 'react-dom'

import './view/stylesheets/sass/skedulo-mobile.scss'

import { JobProductsManagedData, JobProductsCommonData } from 'jp-typegen-library'
import { MobileNativeAttachments, MobileViewWidgets, MobileViewCallbacks, MobileViewDataState } from '@skedulo/sdk-utilities'

import App from './view/App'
import { generateStorageContainer, generateJobProductManager} from './data'

export function bootstrap(
  refId: string,
  data: MobileViewDataState<JobProductsManagedData, JobProductsCommonData>,
  _nativeAttachments: MobileNativeAttachments,
  widgets: MobileViewWidgets,
  callbacks: MobileViewCallbacks<JobProductsManagedData, JobProductsCommonData>,
  callbackBootstrapComplete: () => void
) {
  // Generate storage container and managers for managed schemas
  const storageContainer = generateStorageContainer(data.managedSources)
  const jobProductManager = generateJobProductManager(storageContainer, refId)

  ReactDOM.render(
    <App
      refId={ refId }
      jobProductManager={ jobProductManager }
      storage={ storageContainer }
      common={ data.unmanagedSources }
      widgets={ widgets }
      callbacks={ callbacks }
    />,
    document.getElementById('root'),
    callbackBootstrapComplete
  )
}
