import * as _ from 'lodash'
import {
  NewJobProducts,
  UpdateJobProducts,
  JobProductsManagedData,
  JobProducts as BaseJobProducts,
  JobProduct
} from 'jp-typegen-library'

import { DataStorage, StorageState } from '@skedulo/sdk-utilities'

export function generateStorageContainer(sourceData: StorageState<JobProductsManagedData>): DataStorage<JobProductsManagedData> {
  return new DataStorage(sourceData)
}

export type JobProductManager = ReturnType<typeof generateJobProductManager>

export function generateJobProductManager(storage: DataStorage<JobProductsManagedData>, referenceId: string) {
  return storage.createManagerForSchema<JobProduct, NewJobProducts, UpdateJobProducts, BaseJobProducts>(
    'JobProducts',
    referenceId,
    {
      listAllResolver: jobProducts => jobProducts.filter(jp => jp.JobId === referenceId),
      createMutationResolver: ({ ProductId: potentialPID, ...newJobProduct }, dynamicId) => ({
        ...newJobProduct,
        // Our query type specifies ProductId can be string | null, coerce to null if it wasn't passed in
        ProductId: potentialPID === undefined ? null : potentialPID,
        UID: dynamicId,
        Name: 'temp-jp'
      }),
      updateMutationResolver: ({ Name, ...updatedJobProduct }, existingJobProduct) => ({ ...existingJobProduct, ...updatedJobProduct}),
      deleteMutationResolver: (id, state) => ({ ...state, jobProducts: state.JobProducts.filter(jp => jp.UID !== id) })
    }
  )
}
