import { bootstrap } from './main'

import { createMobileExtensionView } from '@skedulo/sdk-utilities'

// Create new MCP view with bootstrap function
createMobileExtensionView(bootstrap, window)
