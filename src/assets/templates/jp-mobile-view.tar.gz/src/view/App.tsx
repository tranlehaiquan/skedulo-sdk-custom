import * as React from 'react'

import { MobileViewWidgets, MobileViewCallbacks, DataStorage } from '@skedulo/sdk-utilities'
import { JobProductsManagedData, JobProductsUnmanagedData, JobProductCacheData, JobProduct, Product, NewJobProducts, UpdateJobProducts } from 'jp-typegen-library'

import { JobProductManager } from '../data'

import Header from './components/Header'
import JobProductListItem from './components/JobProductListItem'
import ProductListItem from './components/ProductListItem'
import JobProductDetails from './components/JobProductDetails'

interface Props {
  refId: string,
  storage: DataStorage<JobProductsManagedData>
  jobProductManager: JobProductManager
  common: JobProductsUnmanagedData,
  cacheData: JobProductCacheData,
  widgets: MobileViewWidgets,
  callbacks: MobileViewCallbacks<JobProductsManagedData, JobProductsUnmanagedData>
}

interface State {
  view: PageView
  viewData: {
    products: Product[]
    jobProducts: JobProduct[]
  }
  activeSearchTerm?: string
  activeJobProduct?: JobProduct | null
}

enum PageView {
  BaseList,
  JobProductEdit,
  ProductSearch
}

const TemporaryJobProductUID = 'temp-uid'

export default class App extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props)

    this.state = {
      view: PageView.BaseList,
      viewData: {
        jobProducts: props.jobProductManager.listAll(),
        products: props.cacheData.Products
      }
    }
  }

  refreshViewData = () => {
    this.setState({
      viewData: {
        jobProducts: this.props.jobProductManager.listAll(),
        products: this.props.cacheData.Products
      }
    })
  }

  deleteJobProducts = (jobProductId: string) => {
    const { jobProductManager } = this.props

    jobProductManager.deleteItem(jobProductId)

    this.refreshViewData()
  }

  createJobProducts = (jobProduct: NewJobProducts) => {
    const { jobProductManager } = this.props

    jobProductManager.createItem({
      Qty: jobProduct.Qty ,
      JobId: jobProduct.JobId,
      ProductId: jobProduct.ProductId
    })

    this.refreshViewData()
  }

  updateJobProducts = (jobProduct: UpdateJobProducts) => {
    const { jobProductManager } = this.props

    jobProductManager.updateItem({
      UID: jobProduct.UID,
      Qty: jobProduct.Qty || undefined,
      JobId: jobProduct.JobId || undefined,
      ProductId: jobProduct.ProductId
    })

    this.refreshViewData()
  }

  onBack = () => {
    const { callbacks } = this.props

    callbacks.callbackClose()
  }

  onSave = () => {
    const { storage, callbacks, common } = this.props

    callbacks.callbackSave({
      managedSources: storage.export(),
      unmanagedSources: common
    })
  }

  renderBaseList = () => {
    const { onBack, onSave } = this
    const { viewData } = this.state

    const jobProductList = viewData.jobProducts

    const onAdd = () => this.setState({ view: PageView.ProductSearch })

    const onDelete = (jp: JobProduct) => () => this.deleteJobProducts(jp.UID)
    const onEdit = (jp: JobProduct) => () => this.setState({ activeJobProduct: jp, view: PageView.JobProductEdit })

    return (
      <React.Fragment>
        <Header onLeft={ onBack } onRight={ onSave } title="Job Products" />
        <section className="section-products">
          <div className="content-padded rel">
              <h2 className="pad-b">PRODUCTS!</h2>
              <div className="plus-block-btn">
                  <button className="btn btn-green" onClick={ onAdd }>
                      <i className="sk sk-plus" />
                  </button>
              </div>
              <p>&nbsp;</p>
          </div>
          {
            jobProductList.length
              ? jobProductList.map(jp =>
                  <JobProductListItem
                    key={ jp.UID }
                    jobProduct={ jp }
                    onDelete={ onDelete(jp) }
                    onEdit={ onEdit(jp) }
                  />
                )
              : <div className="no-results">No Product</div>
          }
        </section>
      </React.Fragment>
    )
  }

  applySearchTermFilterToProducts = (activeSearchTerm: string) => {
    const { cacheData } = this.props
    const products = cacheData.Products

    const searchTerm = activeSearchTerm.toLowerCase()
    const testFn = (text: string) => text && text.toLowerCase().includes(searchTerm)

    return products.filter(p => testFn(p.Name) || testFn(p.Description || '') || testFn((p as any).ProductCode as any || ''))
  }

  renderProductSearch = () => {
    const { applySearchTermFilterToProducts } = this
    const { widgets, refId } = this.props
    const { activeSearchTerm, viewData } = this.state

    const products = viewData.products

    const onBack = () => this.setState({ view: PageView.BaseList })
    const onSearchTermChange = (event: React.ChangeEvent<HTMLInputElement>) => this.setState({ activeSearchTerm: event.target.value })
    const onScan = () => widgets.scanBarcode().then(result => this.setState({ activeSearchTerm: result })).catch(error => console.log(error))

    const onProductSelect = (product: Product) => () => this.setState({
      view: PageView.JobProductEdit,
      activeJobProduct: createTempJobProduct(product.UID, refId)
    })

    const filteredProducts = activeSearchTerm ? applySearchTermFilterToProducts(activeSearchTerm) : products

    return (
      <React.Fragment>
        <Header onLeft={ onBack } title="Select Products"/>
        <section className="section-products">
          <div className="content-padded">
              <div className="grid">
                  <div className="col-9">
                      <input placeholder="Search Term" value={ activeSearchTerm || '' } onChange={ onSearchTermChange }/>
                  </div>
                  <div className="col-3">
                      <button className="btn btn-block rm-margin-all" onClick={ onScan }><i className="sk sk-qrcode"/>Scan</button>
                  </div>
              </div>
          </div>
          { filteredProducts.length
            ? <div className="list thumbnail-list addProduct-list">
                { filteredProducts.map(prd => <ProductListItem product={ prd } key={ prd.UID} onSelect={ onProductSelect(prd) }/>) }
              </div>
            : <div className="no-results">
                There are no matching parts in the system that match your search. Please check the details and try again.
              </div>
          }
        </section>
      </React.Fragment>
    )
  }

  renderJobProductEdit = () => {
    const { createJobProducts, updateJobProducts } = this
    const { activeJobProduct, viewData } = this.state

    const products = viewData.products

    if (!activeJobProduct) {
      throw new Error('No active job product to render')
    }

    const associatedProduct = products.find(p => p.UID === (activeJobProduct.ProductId))
    if (!associatedProduct) {
      throw new Error('Unable to find associated Product for Job Product')
    }

    const jobProductIsNew = activeJobProduct.UID === TemporaryJobProductUID
    const headerTitlePrefix = jobProductIsNew ? 'Create' : 'Edit'
    const saveTitle = jobProductIsNew ? 'Add' : 'Save'

    const onQuantityUpdate = (qty: number) => this.setState({ activeJobProduct: { ...activeJobProduct, Qty: qty } })
    const onBack = () => this.setState({
      view: PageView.BaseList,
      activeJobProduct: null
    })

    const onSave = () => {
      const { refId } = this.props

      const { activeJobProduct: ajp } = this.state

      jobProductIsNew
        ? createJobProducts({
            Qty: ajp!.Qty,
            ProductId: ajp!.ProductId || '',
            JobId: refId
          })
        : updateJobProducts({
            UID: ajp!.UID,
            Qty: ajp!.Qty
          })

      this.setState({ view: PageView.BaseList, activeJobProduct: null })
    }

    return (
      <React.Fragment>
        <Header onLeft={ onBack } onRight={ onSave } title={ `${headerTitlePrefix} Job Product` } rightTitleOverride={ saveTitle } />
        <section className="section-products">
          <JobProductDetails jobProduct={ activeJobProduct } associatedProduct={ associatedProduct } setQuantity={ onQuantityUpdate } />
        </section>
      </React.Fragment>
    )
  }

  render() {
    const { renderBaseList, renderProductSearch, renderJobProductEdit } = this
    const { view } = this.state

    const renderContent = () => {
      switch (view) {
        case PageView.BaseList:
          return renderBaseList()
        case PageView.ProductSearch:
          return renderProductSearch()
        case PageView.JobProductEdit:
          return renderJobProductEdit()
        default:
          return renderBaseList()
      }
    }

    return renderContent()
  }
}

function createTempJobProduct(productId: string, jobId: string): JobProduct {
  return {
    UID: TemporaryJobProductUID,
    Name: 'temp-jp',
    Qty: 0,
    JobId: jobId,
    ProductId: productId
  }
}
