import * as React from 'react'
import { Product } from 'jp-typegen-library'

interface Props {
  onSelect: () => void
  product: Product
}

export default class ProductListItem extends React.Component<Props, {}> {
  constructor(props: Props) {
    super(props)
  }

  render() {
    const { product, onSelect } = this.props

    return (
      <div className="list-item sked-tap hasArrow" onClick={ onSelect }>
        <div className="sked-thumbnail">
            <i className="sk sk-product" />
        </div>
        <div className="details">
            <p><strong>{ product.Name }</strong></p>
            <p className="trimText fw">{ product.Description }</p>
        </div>
      </div>
    )
  }
}
