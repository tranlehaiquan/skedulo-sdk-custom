import * as React from 'react'
import { JobProduct } from 'jp-typegen-library'

interface Props {
  jobProduct: JobProduct
  onDelete: () => void
  onEdit: () => void
}

export default class JobProductListItem extends React.Component<Props, {}> {
  constructor(props: Props) {
    super(props)
  }

  render() {
    const { jobProduct, onDelete, onEdit } = this.props

    return (
      <div className="list-item focusable">
        <div className="sked-thumbnail">
            <i className="sk sk-product" />
        </div>
        <div className="details">
            <p><strong>{ jobProduct.Name }</strong></p>
        </div>
        <div className="tools">
            <table className="simpletable">
              <tbody>
                <tr>
                    <td><p className="tablelabel">Qty:</p></td>
                    <td><p className="value"><strong>{ jobProduct.Qty }</strong></p></td>
                </tr>
                <tr>
                    <td colSpan={ 2 }>
                        <div className="btn-group">
                            <button className="btn" onClick={ onDelete }>
                                <i className="sk sk-remove"/>
                            </button>
                            <button className="btn" onClick={ onEdit }>
                                <i className="sk sk-edit"/>
                            </button>
                        </div>
                    </td>
                </tr>
              </tbody>
            </table>
        </div>
      </div>
    )
  }
}
