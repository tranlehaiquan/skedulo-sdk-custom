
/**
 * Describe the entry-point into the "skedulo-function" by updating the
 * array returned by the `getRoutes` method with additional routes
 */
import * as _ from 'lodash'

import { FunctionRoute, extractAuthorizationInfoFromHeader } from '@skedulo/sdk-utilities'

// tslint:disable-next-line:no-empty-interface
interface RequestPayload {
}

export function getRoutes(): FunctionRoute[] {
  return [
    {
      method: 'get',
      path: '/ping',
      handler: async (__, headers) => {
        const { token, baseUrl } = extractAuthorizationInfoFromHeader(headers)

        return {
          status: 200,
          body: { result: 'pong', token, baseUrl }
        }
      }
    },
    {
      method: 'post',
      path: '/action',
      handler: async (body: RequestPayload, headers) => {
        const { token, baseUrl } = extractAuthorizationInfoFromHeader(headers)

        return {
          status: 200,
          body: { token, baseUrl, requestBody: body }
        }
      }
    }
  ]
}
