/**
 * This is the "entry point" of the Skedulo function.
 * This usually does not need to be changed. Start writing your function
 * by defining a route in the `routes.ts` file.
 */
import { Function } from '@skedulo/sdk-utilities'

import { getRoutes } from './routes'

// Create a function instance with the given routes
const skeduloFunction = new Function({ useRoutes: true, routes: getRoutes() })

// Export the handler, this step is required!
skeduloFunction.attachHandler(module.exports)
