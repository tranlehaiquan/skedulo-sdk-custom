import * as React from 'react'
import * as ReactDOM from 'react-dom'

import './view/stylesheets/sass/skedulo-mobile.scss'

import { MobileNativeAttachments, MobileViewWidgets, MobileViewCallbacks, MobileViewDataState } from '@skedulo/sdk-utilities'

import App from './view/App'

export function bootstrap(
  refId: string,
  _data: MobileViewDataState<{}, {}>,
  nativeAttachments: MobileNativeAttachments,
  widgets: MobileViewWidgets,
  callbacks: MobileViewCallbacks<{}, {}>,
  callbackBootstrapComplete: () => void
) {
  ReactDOM.render(
    <App
      refId={ refId }
      attachmentServices={ nativeAttachments }
      callbacks={ callbacks }
    />,
    document.getElementById('root'),
    callbackBootstrapComplete
  )
}
