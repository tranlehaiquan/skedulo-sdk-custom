import * as React from 'react'
import * as ReactDOM from 'react-dom'

import './view/stylesheets/sass/skedulo-mobile.scss'

import { MobileViewInitFn } from '@skedulo/sdk-utilities'

import App from './view/App'

export const bootstrap: MobileViewInitFn<{}, {}> = ({refId, nativeAttachments, callbacks, bootstrapComplete, deviceInfo, widgets, data, rootElement}) => {
  ReactDOM.render(
    <App
      refId={ refId }
      attachmentServices={ nativeAttachments }
      callbacks={ callbacks }
    />,
    rootElement,
    bootstrapComplete
  )
}
