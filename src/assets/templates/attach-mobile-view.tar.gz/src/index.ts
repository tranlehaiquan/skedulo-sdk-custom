import { bootstrap } from './main'

import { createMobileExtensionView } from '@skedulo/sdk-utilities'

// Create new Mobile Extension view with bootstrap function
createMobileExtensionView(bootstrap, window)
