import * as React from 'react'
import Gallery, { PhotoProps } from 'react-photo-gallery'

import {
  MobileViewCallbacks,
  MobileNativeAttachments,
  MobileViewAttachmentRequestType,
  MobileNativeAttachment
} from '@skedulo/sdk-utilities'

import Header from './components/Header'
import ModalButton from './components/ModalButton'
import ModalHeader from './components/ModalHeader'
import Modal from './components/Modal'

interface Props {
  refId: string
  attachmentServices: MobileNativeAttachments
  callbacks: MobileViewCallbacks<{}, {}>
}

interface State {
  loading: boolean
  attachments: MobileNativeAttachment[]
  uploadModalOpen: boolean
  modifyModalOpen: boolean
  activeAttachment?: MobileNativeAttachment | null
}

export default class App extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props)

    this.state = {
      attachments: [],
      uploadModalOpen: false,
      modifyModalOpen: false,
      loading: false
    }

    this.refreshAttachments()
  }

  refreshAttachments = async () => {
    this.setState({ loading: true })

    try {
      const attachments = await this.props.attachmentServices.getAttachments()
      this.setState({ attachments })
    } finally {
      this.setState({ loading: false })
    }

  }

  renderLoadingSpinner = () => {
    return <div className="center-in-panel">Loading...</div>
  }

  renderAttachmentView = () => {
    const { activeAttachment } = this.state
    const onBack = () => this.setState({ activeAttachment: null })
    const onModify = () => this.setState({ modifyModalOpen: true })

    return (
      <React.Fragment>
        <Header onLeft={ onBack } onRight={ onModify } rightTitleOverride="Modify" title={ activeAttachment!.name } />
        <section>
          <img src={ activeAttachment!.fileUrl } />
        </section>
      </React.Fragment>
    )
  }

  renderUploadModal = () => {
    const { attachmentServices, refId } = this.props
    const onSelectMethod = (type: MobileViewAttachmentRequestType) => async () => {
      this.setState({ uploadModalOpen: false, loading: true })

      try {
        const cacheResponse = await attachmentServices.createAttachment({
          parentId: refId,
          baseName: null,
          remappingRequired: false,
          requestType: type
        })

        this.setState({ attachments: cacheResponse.allAttachments, loading: false })
      } catch (error) {
        this.setState({ loading: false })
      }
    }

    const onClose = () => this.setState({ uploadModalOpen: false })

    return (
      <Modal>
        <ModalHeader title="Upload attachment" />
        <ModalButton text="Take Photo" onClick={ onSelectMethod(MobileViewAttachmentRequestType.TakePhoto) } />
        <ModalButton text="Get from Gallery" onClick={ onSelectMethod(MobileViewAttachmentRequestType.GetFromGallery) } />
        <ModalButton text="Get from Gallery (Multi)" onClick={ onSelectMethod(MobileViewAttachmentRequestType.GetFromGalleryMulti) } />
        <ModalButton text="Take Signature" onClick={ onSelectMethod(MobileViewAttachmentRequestType.TakeSignature) } />
        <ModalButton text="Close" onClick={ onClose } />
      </Modal>
    )
  }

  renderModifyModal = () => {
    const { attachmentServices } = this.props
    const { activeAttachment } = this.state
    const onDelete = async () => {
      this.setState({ loading: true })
      const cacheResponse = await attachmentServices.deleteAttachment(activeAttachment!.id)

      this.setState({ attachments: cacheResponse, activeAttachment: null, modifyModalOpen: false, loading: false })
    }

    const onDeleteAll = async () => {
      this.setState({ loading: true, modifyModalOpen: false })
      await Promise.all(this.state.attachments.map(a => attachmentServices.deleteAttachment(a.id)))

      this.setState({ attachments: [], activeAttachment: null, modifyModalOpen: false, loading: false })
    }

    const onClose = () => this.setState({ modifyModalOpen: false })

    return (
      <Modal>
        <ModalHeader title="Modify attachment" />
        <ModalButton text="Delete" onClick={ onDelete } />
        <ModalButton text="Delete All lol" onClick={ onDeleteAll } />
        <ModalButton text="Close" onClick={ onClose } />
      </Modal>
    )
  }

  renderBaseView = () => {
    const { callbacks } = this.props
    const { attachments } = this.state

    const onBack = () => callbacks.callbackClose()
    const onAdd = () => this.setState({ uploadModalOpen: true })

    const onSelectAttachment = (event: any, photos: { photo: PhotoProps }) => {
      const referencedAttachment = attachments.find(a => a.id === photos.photo.key)

      this.setState({ activeAttachment: referencedAttachment })
    }

    const photosForGallery: PhotoProps[] = attachments.filter(a => !!a.fileUrl).map(a => ({
      src: 'file://' + a.fileUrl,
      width: 1,
      height: 1,
      key: a.id
    }))

    return (
      <React.Fragment>
        <Header onLeft={ onBack } onRight={ onAdd } title="Job Attachments" rightTitleOverride="Add" />
        <section>
          <Gallery photos={ photosForGallery } onClick={ onSelectAttachment } columns={ 3 } />
        </section>
      </React.Fragment>
    )
  }

  render() {
    const { renderAttachmentView, renderBaseView, renderLoadingSpinner, renderUploadModal, renderModifyModal } = this
    const { activeAttachment, loading, uploadModalOpen, modifyModalOpen } = this.state

    const renderContent = () => {
      if (!!activeAttachment) {
        return renderAttachmentView()
      } else {
        return renderBaseView()
      }
    }

    return (
      <React.Fragment>
        {/* Content */}
        { loading ? renderLoadingSpinner() : null }
        { renderContent() }

        {/* Modals */}
        { uploadModalOpen ? renderUploadModal() : null }
        { modifyModalOpen ? renderModifyModal() : null }
      </React.Fragment>
    )
  }
}
