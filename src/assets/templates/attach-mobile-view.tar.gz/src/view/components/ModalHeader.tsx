import * as React from 'react'

interface Props {
  title: string
}

export default class ModalHeader extends React.Component<Props, {}> {
  constructor(props: Props) {
    super(props)
  }

  render() {
    return (
      <div className="notification-head">
        <h2 className="notification-title">{ this.props.title }</h2>
      </div>
    )
  }
}
