import * as React from 'react'

interface Props {
  title: string
  onLeft: () => void
  onRight?: () => void
  leftTitleOverride?: string
  rightTitleOverride?: string
}

export default class Header extends React.Component<Props, {}> {
  constructor(props: Props) {
    super(props)
  }

  render() {
    const { onRight, rightTitleOverride, leftTitleOverride } = this.props

    return (
      <header className="bar-title">
          <button className="btn transparent fl" onClick={ this.left }>
            { leftTitleOverride || <i className="sk sk-chevron-left" /> }
          </button>

          <h1 className="title"><span>{ this.props.title }</span></h1>

          { onRight ?
            <button className="btn transparent fr" onClick={ this.right }>
              { rightTitleOverride || 'Save' }
            </button> : null
          }
      </header>
    )
  }

  left = () => {
    this.props.onLeft()
  }

  right = () => {
    this.props.onRight!()
  }
}
