import * as React from 'react'

interface Props {
  text: string,
  onClick: () => void
}

export default class ModalButton extends React.Component<Props, {}> {
  constructor(props: Props) {
    super(props)
  }

  render() {
    return (
      <div className="notification-button-group">
        <button className="notification-button" onClick={ this.props.onClick }>{ this.props.text }</button>
      </div>
    )
  }
}
