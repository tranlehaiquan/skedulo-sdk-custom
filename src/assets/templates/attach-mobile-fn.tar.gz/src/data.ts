import { mapValues } from 'lodash'
import { MobileFetchHandler } from '@skedulo/sdk-utilities'

export const fetchHandler: MobileFetchHandler<{}, {}> = async handlerInput => {
  const { services: { AttachmentService }, referenceIds } = handlerInput

  const attachmentsForReferenceIds = await AttachmentService.getAttachmentsForParentIds(referenceIds)

  const attachmentsForResult = mapValues(attachmentsForReferenceIds, (refAttachments, refId) => ({
    [refId]: refAttachments.map(a => ({ id: a.filePtr, name: a.fileName }))
  }))

  return {
    sources: referenceIds.reduce((prev, curr) => ({
      ...prev,
      [curr]: {
        managed: {},
        unmanaged: {}
      }
    }), {}),
    attachments: {
      required: [],
      context: attachmentsForResult
    }
  }
}
