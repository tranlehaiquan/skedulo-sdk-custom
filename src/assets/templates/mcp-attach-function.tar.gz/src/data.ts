import { mapValues } from 'lodash'
import { MCPFetchHandler } from '@skedulo/sdk-utilities'

export const fetchHandler: MCPFetchHandler<{}, {}> = async handlerInput => {
  const { services: { AttachmentService }, referenceIds } = handlerInput

  const attachmentsForReferenceIds = await AttachmentService.getAttachmentsForParentIds(referenceIds)

  const attachmentResult = mapValues(attachmentsForReferenceIds, (result, parentId) => ({
    [parentId]: result.map(r => ({ name: r.fileName, id: r.filePtr }))
  }))

  return {
    managedSources: {},
    commonSources: {},
    attachments: {
      required: [],
      context: attachmentResult
    }
  }
}
