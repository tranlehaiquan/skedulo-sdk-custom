import { MCPFunction } from '@skedulo/sdk-utilities'
import { fetchHandler } from './data'

// Create a function instance with the given routes
const skeduloFunction = new MCPFunction({
  fetch: {
    handler: fetchHandler
  },
  save: {
    graphQLConfiguration: {
      optimize: {
        enabled: true,
        safeKeyMerging: true
      }
    }
  }
})

// Export the handler, this step is required!
skeduloFunction.attachHandler(module.exports)
