import * as React from 'react'
import * as ReactDOM from 'react-dom'

import './view/stylesheets/sass/skedulo-mobile.scss'

import { JobProductsManagedData, JobProductsCommonData } from 'mcp-jp-types'
import { ConnectedPageNativeAttachments, ConnectedPageViewWidgets, ConnectedPageViewCallbacks, ViewDataState } from '@skedulo/sdk-utilities'

import App from './view/App'
import { generateStorageContainer, generateJobProductManager} from './data'

export function bootstrap(
  refId: string,
  data: ViewDataState<JobProductsManagedData, JobProductsCommonData>,
  _nativeAttachments: ConnectedPageNativeAttachments,
  widgets: ConnectedPageViewWidgets,
  callbacks: ConnectedPageViewCallbacks<JobProductsManagedData, JobProductsCommonData>,
  callbackBootstrapComplete: () => void
) {
  // Generate storage container and managers for managed schemas
  const storageContainer = generateStorageContainer(data.managedSources)
  const jobProductManager = generateJobProductManager(storageContainer, refId)

  ReactDOM.render(
    <App
      refId={ refId }
      jobProductManager={ jobProductManager }
      storage={ storageContainer }
      common={ data.commonSources }
      widgets={ widgets }
      callbacks={ callbacks }
    />,
    document.getElementById('root'),
    callbackBootstrapComplete
  )
}
