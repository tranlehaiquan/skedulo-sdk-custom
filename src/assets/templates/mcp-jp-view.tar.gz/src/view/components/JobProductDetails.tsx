import * as React from 'react'
import { JobProduct, Product } from 'mcp-jp-types'

interface Props {
  jobProduct: JobProduct
  associatedProduct: Product
  setQuantity: (qty: number) => void
}

export default class JobProductDetails extends React.Component<Props, {}> {
  constructor(props: Props) {
    super(props)
  }

  render() {
    const { jobProduct, associatedProduct, setQuantity } = this.props

    const setQuantityHandler = (event: React.ChangeEvent<HTMLInputElement>) => setQuantity(parseInt(event.target.value, 10))

    return (
      <React.Fragment>
        <div className="content-padded">
          <div className="idcard">
            <div className="sked-thumbnail">
              <i className="sk sk-product" />
            </div>
            <div className="clearfix">
              <p className="fl">{ associatedProduct.Name }</p>
            </div>
          </div>
        </div>
        <div className="list list-details">
          <div className="list-item">
            <span className="label">Product:</span>
            <span className="field">{ associatedProduct.Name }</span>
          </div>
          <div className="list-item">
            <span className="label">Product Description:</span>
            <span className="field">{ associatedProduct.Description }</span>
          </div>
          <div className="list-item">
            <span className="label">Qty:</span>
            <span className="field">
              <input
                type="number"
                min="1"
                max="9999999999999999"
                name="qty"
                pattern="[0-9]*"
                value={ jobProduct.Qty }
                onChange={ setQuantityHandler }
              />
            </span>
          </div>
        </div>
      </React.Fragment>
    )
  }
}
