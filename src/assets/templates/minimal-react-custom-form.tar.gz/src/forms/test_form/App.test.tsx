import * as React from 'react'
import * as ReactDOM from 'react-dom'

it('runs a no-op test', () => {
  return Promise.resolve()
})
